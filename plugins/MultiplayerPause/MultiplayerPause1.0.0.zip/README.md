# MultiplayerPause

Allows you to pause in multiplayer, type pause in chat or press CTRL + P to pause.

## Changelog

**1.0.0**

* Init Release.
